﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;

namespace ServStructTest1
{
    class Program
    {
        static void Main(string[] args)
        {
            //只有实例化对象，才能使用单例模式
            DataMgr dataMgr = new DataMgr();
            ServNet servNet = new ServNet();
            //创建场景实例
            Scene scene = new Scene();
            servNet.proto = new ProtocolBytes();
            servNet.Start("127.0.0.1", 1234);

            //通过控制台输入，来控制服务器
            while (true)
            {
                string str = Console.ReadLine();
                switch (str)
                {
                    case "quit":
                        servNet.Close();
                        return;
                    case "print":
                        servNet.Print();
                        
                        break;
                }
            }
        }
    }
}
