﻿using System.Collections;
using System.Collections.Generic;


public class ScenePlayer{
    public string id;
    public float x;
    public float y;
    public float z;

    public int score = 0;
}
